
import SwiftUI


struct SupportedDeviceView: View {
    
    
    @State var shouldShowTheMonkey = false
    
//    init() {
//
//        viewModel.startup()
//
//    }
    
    @ObservedObject var viewModel  : MPNSession
    
    
  
    
    var body: some View {
        
        VStack{
            Text(viewModel.deviseName ?? "")
            Text(viewModel.details ?? "")
            Text(viewModel.distanceN ?? "")
            Text("up , down  degrees")
            Text("\(Int(viewModel.diractionN ?? 0))")
            Text("right , left degrees")
            Text("\(Int(viewModel.diractionNN ?? 0))")
            Text(viewModel.monky ?? "Null").rotationEffect(.degrees((viewModel.diractionN ?? 0) ))
          
            
        }
        
    }
}


//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        SupportedDeviceView()
//    }
//}



