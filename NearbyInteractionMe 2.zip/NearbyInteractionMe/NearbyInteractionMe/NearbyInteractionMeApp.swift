//
//  NearbyInteractionMeApp.swift
//  NearbyInteractionMe
//
//  Created by RMP on 22/07/1444 AH.
//

import SwiftUI
import NearbyInteraction


@main
struct NearbyInteractionMeApp: App {
  @ObservedObject var viewModel = MPNSession()
    var body: some Scene {
        
        WindowGroup {
           
                
                hostandjoin(vm: viewModel)
            
        }
        
    }
    
    
}
