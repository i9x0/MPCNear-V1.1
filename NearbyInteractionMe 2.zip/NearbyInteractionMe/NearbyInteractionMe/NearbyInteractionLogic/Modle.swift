//
//  Modle.swift
//  NearbyInteractionMe
//
//  Created by Abu3abd on 26/07/1444 AH.
//

import Foundation
import NearbyInteraction
struct Peers : Hashable{
    var name : String
    var token : NIDiscoveryToken
}
