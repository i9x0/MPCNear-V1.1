////
////  HostDevice.swift
////  NearbyInteractionMe
////
////  Created by Abu3abd on 25/07/1444 AH.
////
//
//import SwiftUI
//
//struct HostDevice: View {
//    @ObservedObject var viewModel : MPNSession
//    var body: some View {
//        VStack{
//            Button("Host"){
//                SupportedDeviceView(viewModel: viewModel)
//
//            }
//            Button("Join in"){
//                SupportedDeviceView(viewModel: viewModel)
//
//            }
//        }.font(.largeTitle)
//    }
//}
//
//struct HostDevice_Previews: PreviewProvider {
//    static var previews: some View {
//        HostDevice()
//    }
//}
