//
//  hostandjoin.swift
//  NearbyInteractionMe
//
//  Created by Abu3abd on 26/07/1444 AH.
//

import SwiftUI

struct hostandjoin: View {
    @ObservedObject var vm : MPNSession
    @State var sheetview = false
    var body: some View {
       
            VStack{
                List(vm.peerss , id: \.self){item in
                    Text(item.name)
                    Text("\(item.token)")
                }
                Button("Host"){
                    vm.mpc?.host = true
                    vm.mpc?.start()
                    
                }
                Button("Join"){
            sheetview = true
                    vm.mpc?.host = false
                    vm.mpc?.joinin()
                    
                    
                }.sheet(isPresented: $sheetview) {
                    SupportedDeviceView(viewModel: vm)
                }
                
            }
        
    }
}

//struct hostandjoin_Previews: PreviewProvider {
//    static var previews: some View {
//        hostandjoin()
//    }
//}
